1. 作業系統是 windows 10，Python 的版本為 3.8.2


2. 由於 code 中使用到一些 Library 像是：pandas, numpy，若電腦中沒有安裝過這些 Library，請先使用下面指令進行安裝

$ pip install pandas
$ pip install numpy


3. 接著即可直接使用指令進行編譯

$ python HW2.py


4. 結果將會輸出當 O1=2, O2=4 時，兩種方法所估計出的 chance of admit 以及對應的 squared error


5. 如果無法執行或有任何疑問可以聯絡我，我將會幫忙排除問題

E-mail: chenwy0806@gapp.nthu.edu.tw